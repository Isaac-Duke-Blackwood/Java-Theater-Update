//Name: Isaac Blackwood
//Net ID: idb170030
package Tickets;

public class InvalidTicketNumberException extends TicketsPackageDataMemberException 
{
	private static final long serialVersionUID = 4147225952473350631L;
}
