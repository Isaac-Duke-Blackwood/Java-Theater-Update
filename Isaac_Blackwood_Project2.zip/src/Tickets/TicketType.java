//Name: Isaac Blackwood
//Net ID: idb170030
////Project description requires that the ticket type be stored as a char type, but this would be better.
//package Tickets;
//
//public enum TicketType
//{
//	ADULT 
//	{
//		public char toChar() 
//		{
//			return 'A';
//		}
//	},
//	CHILD
//	{
//		public char toChar()
//		{
//			return 'C';
//		}
//	}, 
//	SENIOR
//	{
//		public char toChar()
//		{
//			return 'S';
//		}
//	};
//	
//	
//	public abstract char toChar();
//	@Override
//	public String toString()
//	{
//		return Character.toString(this.toChar());
//	}
//}