//Name: Isaac Blackwood
//Net ID: idb170030
package Tickets;

public enum Direction 
{
	UP, DOWN, LEFT, RIGHT;
}
