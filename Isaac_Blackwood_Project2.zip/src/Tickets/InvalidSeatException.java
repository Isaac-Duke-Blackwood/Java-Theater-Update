//Name: Isaac Blackwood
//Net ID: idb170030
package Tickets;

public class InvalidSeatException extends TicketsPackageDataMemberException 
{
	private static final long serialVersionUID = 3145163471656742126L;

}
