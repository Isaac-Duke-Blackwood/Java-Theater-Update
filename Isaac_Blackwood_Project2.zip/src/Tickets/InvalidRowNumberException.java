//Name: Isaac Blackwood
//Net ID: idb170030
package Tickets;

public class InvalidRowNumberException extends TicketsPackageDataMemberException 
{
	private static final long serialVersionUID = 4873312343854776928L;
}
