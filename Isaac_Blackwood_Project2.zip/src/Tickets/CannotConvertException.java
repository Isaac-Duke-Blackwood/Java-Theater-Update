//Name: Isaac Blackwood
//Net ID: idb170030
package Tickets;

public class CannotConvertException extends Exception 
{
	private static final long serialVersionUID = -2784217490941381879L;
}
