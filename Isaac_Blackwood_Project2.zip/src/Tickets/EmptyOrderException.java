//Name: Isaac Blackwood
//Net ID: idb170030
package Tickets;

public class EmptyOrderException extends Exception 
{
	private static final long serialVersionUID = -5643454302734904016L;
}
