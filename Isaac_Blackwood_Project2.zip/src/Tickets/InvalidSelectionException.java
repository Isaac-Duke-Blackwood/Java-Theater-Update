//Name: Isaac Blackwood
//Net ID: idb170030
package Tickets;

public class InvalidSelectionException extends TicketsPackageDataMemberException
{
	private static final long serialVersionUID = -5735799327001055205L;
}
