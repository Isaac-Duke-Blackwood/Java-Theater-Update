//Name: Isaac Blackwood
//Net ID: idb170030
package Tickets;

public class TicketsPackageDataMemberException extends Exception 
{
	private static final long serialVersionUID = -1666558869524160295L;
}
